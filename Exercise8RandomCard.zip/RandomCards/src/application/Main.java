/*Chris Hawkins 
 * CST 105 Exercise 8
 * This is my own work.
 */

package application;
	
import java.util.ArrayList;
import javafx.application.Application;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.image.ImageView;
import javafx.scene.image.Image;
import javafx.scene.layout.HBox;

public class Main extends Application {
    @Override
    public void start(Stage primaryStage) {
        ArrayList<String> cards = new ArrayList<>();

        for (int i = 0; i < 52; i++) {
            cards.add(String.valueOf(i + 1));
        }

        java.util.Collections.shuffle(cards);

        ImageView view1 = new ImageView(
                new Image("https://liveexample.pearsoncmg.com/book/image/card/" + cards.get(0) + ".png"));
        ImageView view2 = new ImageView(
                new Image("https://liveexample.pearsoncmg.com/book/image/card/" + cards.get(1) + ".png"));
        ImageView view3 = new ImageView(
                new Image("https://liveexample.pearsoncmg.com/book/image/card/" + cards.get(2) + ".png"));

        HBox root = new HBox();

        root.getChildren().add(view1);
        root.getChildren().add(view2);
        root.getChildren().add(view3);

        Scene scene = new Scene(root);

        primaryStage.setTitle("Random Card Game");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
