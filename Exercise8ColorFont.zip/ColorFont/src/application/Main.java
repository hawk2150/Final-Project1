/*Chris Hawkins 
 * CST 105 Exercise 8
 * This is my own work.
 */
package application;
	
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.layout.Pane;
import javafx.scene.paint.Color;
import javafx.scene.text.Font;
import javafx.scene.text.FontPosture;
import javafx.scene.text.FontWeight;
import javafx.scene.text.Text;


	public class Main extends Application {
		@Override
		public void start(Stage primaryStage) throws Exception {
			
			Pane pane = new Pane();
			pane.setPadding(new Insets(5, 5, 5, 5));
			Text text1 = new Text(20, 20, "C\no\nl\no\nr");
			text1.setFont(Font.font("Times New Roman", FontWeight.BOLD, FontPosture.ITALIC, 22));
			pane.getChildren().add(text1);
			
			Text text2 = new Text(20, 20,"C\no\nl\no\nr");
			text2.setFont(Font.font("Times New Roman", FontWeight.BOLD, FontPosture.ITALIC, 22));
			text2.setFill(Color.BLUE);
			pane.getChildren().add(text2);
			
			
			Scene scene = new Scene(pane);
			primaryStage.setTitle("Color Font");
			primaryStage.setScene(scene);
			primaryStage.show();
		}}
